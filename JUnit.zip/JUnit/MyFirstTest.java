package testing;

import org.junit.jupiter.api.Test;

public class MyFirstTest {

	//method creation
	
	
	@Test
	void display()
	{
		System.out.println("Hello World");
	}
	
}
