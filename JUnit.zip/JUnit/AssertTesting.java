package testing;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

//Asserting Testing Demo

public class AssertTesting {

	@Test
	public void testForAssetEquals()
	{
		int result = 1;
		int expected = 1;
		
		assertEquals(result, expected);
		
	}
	
	@Test
	public void testForAssetTrue()
	{
		assertTrue("Hello".contains("e"));
		
	}
	
	
	@Test
	public void testForAssetFalse()
	{
		assertFalse("Hello".contains("s"));
		
	}
	
	
	@Test
	public void testForNull()
	{
		
		String s = null;
		assertNull(s);
		
	}
	
	@Test
	public void testFail()
	{
		fail("It is supposed to be fail");
	}

	
	
}
