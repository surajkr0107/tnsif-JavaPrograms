package testing;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

//Before Each
//After Each
//Before All
//After All
//Test

@TestInstance(Lifecycle.PER_CLASS)
public class TestLifeCycle {

	
	
	@BeforeEach
	void beforeEachTest()
	{
		System.out.println("Before Each Test"); //2nd printed //5th printed
	}
	
	@AfterEach
	void afterEachTest()
	{
		System.out.println("After Each Test"); //4th printed //7th printed
	}
	
	@BeforeAll
	void beforeAll()
	{
		System.out.println("Before All"); //1st printed
	}
	
	@AfterAll
	void afterAll()
	{
		System.out.println("Before All"); //8th printed
	}
	
	
	@Test
	void test1()
	{
		System.out.println("Test Method 1"); //3rd printed
		
	}
	
	@Test
	void test2()
	{
		System.out.println("Test Method 2"); //6th printed
		
	}
	

	
}
