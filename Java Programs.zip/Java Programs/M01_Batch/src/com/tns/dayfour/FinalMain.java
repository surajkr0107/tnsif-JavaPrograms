package com.tns.dayfour;

public class FinalMain extends FinalMethod{

		// TODO Auto-generated method stub
	
	@Override void show()
	{
		System.out.println("This is value of a = "+a);
	}
	}

