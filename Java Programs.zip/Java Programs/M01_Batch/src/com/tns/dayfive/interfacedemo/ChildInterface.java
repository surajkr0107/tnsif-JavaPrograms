package com.tns.dayfive.interfacedemo;


//child interface
public interface ChildInterface extends InterfaceDemo{

	public void show();
	
}
