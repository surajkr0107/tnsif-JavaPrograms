package vehicle.rangerover;

public class Car {

	private Wheel wheelObj; //Reference variable or wheel object

	public Wheel getWheelObj() {
		return wheelObj;
	}

	public void setWheelObj(Wheel wheelObj) {
		this.wheelObj = wheelObj;
	}
	
	
	
	
	
}
