package jdbc.demo;

//Import the SQL package
//Register/load the driver
//Establish the connection
//Create the statement
//Execute the Query
//ResultSet
//Close the connection

import java.sql.*; //1st step 

public class JDBC_Demo {

	
	//Registered the driver - 2nd step
	
	public static void main(String [] args)
	{
		
		String url = "jdbc:postgresql://localhost:5432/m01_batch";
		String username = "postgres";
		String password = "Data@123";
		
		try {
			
			//Loaded the driver ---> 2nd step
			Class.forName("org.postgresql.Driver");
			
			//Established the connection -----> 3rd step
			Connection con = DriverManager.getConnection(url,username, password);
			 
			//Create the statement----->4th step
			Statement st = con.createStatement();
			
			//Execute the Query------->5th step
			String query = "SELECT * FROM attendance";
			
			//ResultSet----->6th Step
			ResultSet rs = st.executeQuery(query);
			
			while (rs.next())
			{
				String table = rs.getInt(1) +":"+ rs.getString(2) +":"+ rs.getString(3);
				System.out.println(table);
			}
			
			//Closed the connection ----> 7th step
			rs.close();
			st.close();
			con.close();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}
}
