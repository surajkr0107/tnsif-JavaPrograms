package jdbc.demo;

import java.sql.*;


public class PreparedStatementDemo {

	public static void main(String[] args) throws Exception {
		
			
			String url = "jdbc:postgresql://localhost:5432/m01_batch";
			String username = "postgres";
			String password = "Data@123";
			
			String name = "Sen";
			String department = "IT";
		
		String query = "INSERT INTO attendance(name,department) VALUES (?,?)";
		
		
		try {
			
			//Loaded the driver ---> 2nd step
			Class.forName("org.postgresql.Driver");
			
			//Established the connection -----> 3rd step
			Connection con = DriverManager.getConnection(url,username, password);
			 
			PreparedStatement st = con.prepareStatement(query);
			
			
			st.setString(1, name);
			st.setString(2, department);
			
			
			int rs = st.executeUpdate();
			System.out.println(rs +" row/s affected");
			
			st.close();
			con.close();
		}
		
	
		
	catch (Exception e) {
		e.printStackTrace();
	}

	}
}
